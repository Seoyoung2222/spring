create definer = root@localhost view menu_view as
select `m`.`menu_id`                                                                                  AS `menu_id`,
       `m`.`menu_name`                                                                                AS `menu_name`,
       concat(substr(`b`.`business_name`, 1, 1), repeat('*', (char_length(`b`.`business_name`) - 1))) AS `business`,
       `m`.`price`                                                                                    AS `price`,
       `m`.`likes`                                                                                    AS `evaluation`
from (`mydatabase`.`businesses` `b` join `mydatabase`.`menus` `m` on ((`m`.`fk_business_id` = `b`.`business_id`)));

