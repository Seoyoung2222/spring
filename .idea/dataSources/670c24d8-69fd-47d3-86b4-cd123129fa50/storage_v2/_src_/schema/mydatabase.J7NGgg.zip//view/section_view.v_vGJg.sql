create definer = root@localhost view section_view as
select `mydatabase`.`sections`.`section_id` AS `section_id`, `mydatabase`.`sections`.`section_name` AS `section_name`
from `mydatabase`.`sections`;

