create definer = root@localhost view business_view as
select `s`.`section_name`                                                                                         AS `section_name`,
       `b`.`business_name`                                                                                        AS `business_name`,
       (select count(0)
        from `mydatabase`.`menus` `m`
        where (`m`.`fk_business_id` = `b`.`business_id`))                                                         AS `menu_count`,
       (select avg(`m`.`likes`)
        from `mydatabase`.`menus` `m`
        where (`m`.`fk_business_id` = `b`.`business_id`))                                                         AS `menu_avg_likes`,
       (select avg(`r`.`stars`)
        from `mydatabase`.`ratings` `r`
        where (`r`.`fk_business_id` = `b`.`business_id`))                                                         AS `avg_stars`,
       (select `r`.`comment`
        from `mydatabase`.`ratings` `r`
        where (`r`.`fk_business_id` = `b`.`business_id`)
        order by `r`.`created` desc
        limit 1)                                                                                                  AS `recent_comment`
from (`mydatabase`.`businesses` `b` join `mydatabase`.`sections` `s` on ((`s`.`section_id` = `b`.`fk_section_id`)));

